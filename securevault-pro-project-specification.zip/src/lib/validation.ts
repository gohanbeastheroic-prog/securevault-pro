import { z } from "zod";

export const emailSchema = z.string().trim().email("Enter a valid email address.").max(320);

export const passwordSchema = z
  .string()
  .min(10, "Password must be at least 10 characters.")
  .max(200)
  .refine((v) => /[a-z]/.test(v) && /[A-Z]/.test(v) && /[0-9]/.test(v), {
    message: "Password must include upper and lower case letters and a number.",
  });

export const registerSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
});

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Password is required."),
  totpCode: z.string().optional(),
});

export const forgotPasswordSchema = z.object({ email: emailSchema });

export const resetPasswordSchema = z.object({
  token: z.string().min(10),
  password: passwordSchema,
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: passwordSchema,
});

export const changeEmailSchema = z.object({
  newEmail: emailSchema,
  currentPassword: z.string().min(1),
});

export const vaultSetupSchema = z.object({
  salt: z.string().min(10),
  kdfIterations: z.number().int().min(100000).max(2000000),
  verifier: z.string().min(10),
  recoveryCiphertext: z.string().optional(),
  recoveryIv: z.string().optional(),
  recoverySalt: z.string().optional(),
  recoveryVerifier: z.string().optional(),
});

export const vaultUnlockSchema = z.object({
  verifier: z.string().min(10),
});

export const vaultChangePasswordSchema = z.object({
  oldVerifier: z.string().min(10),
  newSalt: z.string().min(10),
  newKdfIterations: z.number().int().min(100000).max(2000000),
  newVerifier: z.string().min(10),
  reencryptedItems: z
    .array(z.object({ id: z.string().uuid(), ciphertext: z.string(), iv: z.string() }))
    .default([]),
});

export const vaultItemSchema = z.object({
  type: z.enum([
    "email", "social", "website", "device", "note", "custom",
    "wifi", "license", "server", "api_key", "recovery_code",
  ]),
  categoryId: z.string().uuid().nullable().optional(),
  ciphertext: z.string().min(1),
  iv: z.string().min(1),
  favorite: z.boolean().optional(),
  archived: z.boolean().optional(),
  sizeBytes: z.number().int().min(0).max(2_000_000),
});

export const vaultItemUpdateSchema = vaultItemSchema.partial();

export const vaultCategorySchema = z.object({
  name: z.string().trim().min(1).max(100),
  icon: z.string().max(50).optional(),
});

export const financeAccountSchema = z.object({
  name: z.string().trim().min(1).max(100),
  type: z.enum(["bank", "cash", "wallet", "card", "other"]),
  currency: z.string().trim().min(1).max(10).default("USD"),
  startingBalance: z.number().finite().default(0),
});

export const financeCategorySchema = z.object({
  name: z.string().trim().min(1).max(100),
  type: z.enum(["income", "expense"]),
  icon: z.string().max(50).optional(),
});

export const financeTransactionSchema = z.object({
  type: z.enum(["income", "expense", "transfer", "refund", "adjustment"]),
  title: z.string().trim().min(1).max(200),
  amount: z.number().finite().positive("Amount must be greater than zero."),
  currency: z.string().trim().min(1).max(10).default("USD"),
  categoryId: z.string().uuid().nullable().optional(),
  accountId: z.string().uuid().nullable().optional(),
  transferToAccountId: z.string().uuid().nullable().optional(),
  paymentMethod: z.string().max(50).optional(),
  date: z.string().min(1),
  notes: z.string().max(2000).optional(),
  hasReceipt: z.boolean().optional(),
  receiptNote: z.string().max(200).optional(),
});

export const financeBudgetSchema = z.object({
  name: z.string().trim().min(1).max(100),
  categoryId: z.string().uuid().nullable().optional(),
  amount: z.number().finite().positive(),
  month: z.number().int().min(1).max(12),
  year: z.number().int().min(2000).max(2100),
});

export const savingsGoalSchema = z.object({
  name: z.string().trim().min(1).max(150),
  targetAmount: z.number().finite().positive(),
  currentAmount: z.number().finite().min(0).default(0),
  targetDate: z.string().optional(),
  notes: z.string().max(2000).optional(),
});

export const recurringTransactionSchema = z.object({
  type: z.enum(["income", "expense"]),
  title: z.string().trim().min(1).max(200),
  amount: z.number().finite().positive(),
  currency: z.string().trim().min(1).max(10).default("USD"),
  categoryId: z.string().uuid().nullable().optional(),
  accountId: z.string().uuid().nullable().optional(),
  paymentMethod: z.string().max(50).optional(),
  frequency: z.enum(["daily", "weekly", "monthly", "yearly"]),
  startDate: z.string().min(1),
  notes: z.string().max(2000).optional(),
  active: z.boolean().optional(),
});

export const adminUserActionSchema = z.object({
  action: z.enum(["suspend", "reactivate", "deactivate", "request_deletion", "cancel_deletion", "delete_now"]),
  reason: z.string().max(500).optional(),
});

export const adminSettingsSchema = z.object({
  maxVaultItems: z.number().int().min(10).max(1_000_000),
  maxSecureNotes: z.number().int().min(10).max(1_000_000),
  maxBackupSizeBytes: z.number().int().min(1024),
  maxFileUploadBytes: z.number().int().min(1024),
  maxTotalStorageBytes: z.number().int().min(1024),
});

export const bulkDeleteSchema = z.object({
  userIds: z.array(z.string().uuid()).min(1),
  currentPassword: z.string().min(1),
  totpCode: z.string().min(6),
  confirmationPhrase: z.literal("DELETE THESE ACCOUNTS"),
});
