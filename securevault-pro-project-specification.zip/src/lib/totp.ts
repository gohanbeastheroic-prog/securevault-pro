import "server-only";
import { generateSecret, generate, verify, generateURI } from "otplib";

export function createTotpSecret(): string {
  return generateSecret();
}

export async function generateTotpToken(secret: string): Promise<string> {
  return generate({ secret });
}

export async function verifyTotpToken(token: string, secret: string): Promise<boolean> {
  try {
    const result = await verify({ secret, token, epochTolerance: 1 });
    return result.valid;
  } catch {
    return false;
  }
}

export function totpProvisioningUri(label: string, secret: string): string {
  return generateURI({ issuer: "SecureVault Pro", label, secret });
}
