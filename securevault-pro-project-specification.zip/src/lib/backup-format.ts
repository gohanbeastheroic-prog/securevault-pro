export const BACKUP_FORMAT_VERSION = 1;

export type BackupVaultItem = {
  id: string;
  type: string;
  categoryId: string | null;
  ciphertext: string;
  iv: string;
  favorite: boolean;
  archived: boolean;
  sizeBytes: number;
};

export type BackupFinanceSnapshot = {
  accounts: Array<{ id: string; name: string; type: string; currency: string; startingBalance: string }>;
  categories: Array<{ id: string; name: string; type: string; icon: string | null }>;
  transactions: Array<Record<string, unknown>>;
  budgets: Array<Record<string, unknown>>;
  goals: Array<Record<string, unknown>>;
  recurring: Array<Record<string, unknown>>;
};

export type BackupPayload = {
  formatVersion: number;
  createdAt: string;
  containsVault: boolean;
  containsFinance: boolean;
  vault: {
    categories: Array<{ id: string; name: string; icon: string | null }>;
    items: BackupVaultItem[];
  } | null;
  finance: {
    encrypted: true;
    ciphertext: string;
    iv: string;
    tag: string;
  } | null;
  checksum: string;
};
