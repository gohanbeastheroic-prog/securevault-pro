import "server-only";

/**
 * Minimal transactional email sender.
 * If RESEND_API_KEY is configured, emails are sent via the Resend API.
 * Otherwise (local/dev), the email content is logged server-side so the
 * flow can still be exercised end-to-end without a real mail provider.
 */
export async function sendEmail(to: string, subject: string, html: string): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM || "SecureVault Pro <no-reply@securevaultpro.app>";

  if (!apiKey) {
    console.log(`[email:dev-mode] To: ${to} | Subject: ${subject}\n${html}`);
    return;
  }

  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from, to, subject, html }),
    });
  } catch (err) {
    console.error("Failed to send email via provider, falling back to log:", err);
    console.log(`[email:fallback] To: ${to} | Subject: ${subject}\n${html}`);
  }
}

export function verificationEmailHtml(link: string) {
  return `<p>Welcome to SecureVault Pro. Confirm your email address to activate your account:</p>
  <p><a href="${link}">${link}</a></p>
  <p>This link expires in 24 hours. If you did not create this account, ignore this email.</p>`;
}

export function passwordResetEmailHtml(link: string) {
  return `<p>A password reset was requested for your SecureVault Pro account.</p>
  <p><a href="${link}">${link}</a></p>
  <p>This link expires in 1 hour. If you did not request this, you can safely ignore this email — your password will not change.</p>
  <p>Note: resetting your account password never changes or reveals your separate Vault Master Password.</p>`;
}

export function securityAlertEmailHtml(message: string) {
  return `<p>Security notice for your SecureVault Pro account:</p><p>${message}</p>`;
}
