import "server-only";

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();

// Periodically clear stale buckets to avoid unbounded memory growth.
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt < now) buckets.delete(key);
  }
}, 60_000).unref?.();

/**
 * Simple fixed-window rate limiter keyed by identifier + action.
 * Returns true if the request is allowed, false if the limit was exceeded.
 */
export function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const existing = buckets.get(key);

  if (!existing || existing.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }

  if (existing.count >= limit) {
    return false;
  }

  existing.count += 1;
  return true;
}

export function rateLimitRemaining(key: string): number {
  const bucket = buckets.get(key);
  if (!bucket) return Infinity;
  return Math.max(0, Math.ceil((bucket.resetAt - Date.now()) / 1000));
}
