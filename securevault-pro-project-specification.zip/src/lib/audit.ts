import "server-only";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";

type AuditParams = {
  actorUserId?: string | null;
  actorRole?: string | null;
  action: string;
  targetUserId?: string | null;
  metadata?: Record<string, unknown>;
  ipAddress?: string | null;
};

/** Record a safe audit event. Never pass secrets, passwords, tokens, or decrypted content here. */
export async function recordAudit(params: AuditParams): Promise<void> {
  try {
    await db.insert(auditLogs).values({
      actorUserId: params.actorUserId ?? null,
      actorRole: params.actorRole ?? null,
      action: params.action,
      targetUserId: params.targetUserId ?? null,
      metadata: params.metadata ?? {},
      ipAddress: params.ipAddress ?? null,
    });
  } catch (err) {
    console.error("Failed to record audit log", err);
  }
}
