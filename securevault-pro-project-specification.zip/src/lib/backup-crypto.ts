import "server-only";
import { createCipheriv, createDecipheriv, createHash, randomBytes } from "crypto";

function getKey(): Buffer {
  const b64 = process.env.BACKUP_ENCRYPTION_KEY;
  if (!b64) throw new Error("BACKUP_ENCRYPTION_KEY is not configured on the server.");
  const key = Buffer.from(b64, "base64");
  if (key.length !== 32) throw new Error("BACKUP_ENCRYPTION_KEY must decode to 32 bytes.");
  return key;
}

/** Server-side at-rest encryption for the finance portion of backup files. */
export function encryptServerSide(plaintext: string): { ciphertext: string; iv: string; tag: string } {
  const key = getKey();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return { ciphertext: encrypted.toString("base64"), iv: iv.toString("base64"), tag: tag.toString("base64") };
}

export function decryptServerSide(ciphertext: string, iv: string, tag: string): string {
  const key = getKey();
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(iv, "base64"));
  decipher.setAuthTag(Buffer.from(tag, "base64"));
  const decrypted = Buffer.concat([decipher.update(Buffer.from(ciphertext, "base64")), decipher.final()]);
  return decrypted.toString("utf8");
}

export function sha256(data: string): string {
  return createHash("sha256").update(data).digest("hex");
}
