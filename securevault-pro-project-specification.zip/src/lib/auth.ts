import "server-only";
import { cookies, headers } from "next/headers";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { and, eq, gt, isNull } from "drizzle-orm";
import { generateToken, hashToken } from "./crypto-server";
import { SESSION_COOKIE, SESSION_TTL_MS } from "./constants";

export type SessionUser = {
  id: string;
  email: string;
  role: string;
  status: string;
  emailVerified: boolean;
  twoFactorEnabled: boolean;
};

export async function getClientIp(): Promise<string> {
  const h = await headers();
  return (
    h.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    h.get("x-real-ip") ||
    "unknown"
  );
}

export async function getUserAgent(): Promise<string> {
  const h = await headers();
  return h.get("user-agent") || "unknown";
}

export async function createSession(userId: string): Promise<string> {
  const token = generateToken(32);
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  const ip = await getClientIp();
  const ua = await getUserAgent();

  await db.insert(sessions).values({
    userId,
    tokenHash,
    expiresAt,
    ipAddress: ip,
    userAgent: ua,
  });

  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });

  return token;
}

export async function destroySession(): Promise<void> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (token) {
    const tokenHash = hashToken(token);
    await db.update(sessions).set({ revokedAt: new Date() }).where(eq(sessions.tokenHash, tokenHash));
  }
  cookieStore.delete(SESSION_COOKIE);
}

export async function getCurrentUser(): Promise<SessionUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const tokenHash = hashToken(token);
  const now = new Date();

  const rows = await db
    .select({
      sessionId: sessions.id,
      expiresAt: sessions.expiresAt,
      revokedAt: sessions.revokedAt,
      user: users,
    })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, tokenHash), gt(sessions.expiresAt, now), isNull(sessions.revokedAt)))
    .limit(1);

  const row = rows[0];
  if (!row) return null;
  if (row.user.deletedAt) return null;

  // touch last used (best-effort, non-blocking)
  db.update(sessions).set({ lastUsedAt: now }).where(eq(sessions.id, row.sessionId)).catch(() => {});
  db.update(users).set({ lastActivityAt: now }).where(eq(users.id, row.user.id)).catch(() => {});

  return {
    id: row.user.id,
    email: row.user.email,
    role: row.user.role,
    status: row.user.status,
    emailVerified: row.user.emailVerified,
    twoFactorEnabled: row.user.twoFactorEnabled,
  };
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

/** Require an authenticated user with an allowed account status. Throws ApiError otherwise. */
export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) throw new ApiError("Authentication required.", 401);
  if (user.status === "suspended") throw new ApiError("This account has been suspended.", 403);
  if (user.status === "deactivated") throw new ApiError("This account has been deactivated.", 403);
  return user;
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.role !== "admin" || !user.twoFactorEnabled) {
    throw new ApiError("Administrator access required.", 403);
  }
  return user;
}
