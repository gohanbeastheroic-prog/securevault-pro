"use client";

/**
 * Zero-knowledge client-side cryptography for SecureVault Pro.
 *
 * - Vault Master Password never leaves the browser.
 * - A per-user random salt + PBKDF2-SHA256 (high iteration count) derives a 256-bit AES key.
 * - AES-256-GCM encrypts every vault item payload with a fresh random 12-byte nonce.
 * - A non-reversible "verifier" (derived from the vault key, not the password) is sent to the
 *   server so it can gate unlock attempts & rate-limit guesses WITHOUT ever learning the
 *   vault key or password itself.
 */

const PBKDF2_ITERATIONS_DEFAULT = 310_000;

function toB64(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function fromB64(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

export function randomSaltB64(bytes = 16): string {
  const arr = crypto.getRandomValues(new Uint8Array(bytes));
  return toB64(arr);
}

async function deriveKeyMaterial(secret: string, saltB64: string, iterations: number): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey("raw", enc.encode(secret), "PBKDF2", false, [
    "deriveBits",
    "deriveKey",
  ]);
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: fromB64(saltB64) as BufferSource,
      iterations,
      hash: "SHA-256",
    },
    baseKey,
    { name: "AES-GCM", length: 256 },
    true,
    ["encrypt", "decrypt"],
  );
}

export type VaultKey = { key: CryptoKey; raw: ArrayBuffer };

export async function deriveVaultKey(
  masterPassword: string,
  saltB64: string,
  iterations = PBKDF2_ITERATIONS_DEFAULT,
): Promise<VaultKey> {
  const key = await deriveKeyMaterial(masterPassword, saltB64, iterations);
  const raw = await crypto.subtle.exportKey("raw", key);
  return { key, raw };
}

/** Derive a server-verifiable (but non-reversible) verifier from the vault key. */
export async function deriveVerifier(vaultKey: VaultKey): Promise<string> {
  const material = new Uint8Array([...new Uint8Array(vaultKey.raw), ...new TextEncoder().encode("sv-verify-v1")]);
  const digest = await crypto.subtle.digest("SHA-256", material);
  return toB64(digest);
}

export async function encryptJson(vaultKey: VaultKey, data: unknown): Promise<{ ciphertext: string; iv: string }> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const enc = new TextEncoder();
  const plaintext = enc.encode(JSON.stringify(data));
  const cipherBuf = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv as BufferSource }, vaultKey.key, plaintext as BufferSource);
  return { ciphertext: toB64(cipherBuf), iv: toB64(iv) };
}

export async function decryptJson<T = unknown>(vaultKey: VaultKey, ciphertext: string, iv: string): Promise<T> {
  const cipherBytes = fromB64(ciphertext);
  const ivBytes = fromB64(iv);
  const plainBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv: ivBytes as BufferSource }, vaultKey.key, cipherBytes as BufferSource);
  const dec = new TextDecoder();
  return JSON.parse(dec.decode(plainBuf)) as T;
}

/** Wrap (encrypt) the vault key itself using a secondary secret, e.g. a recovery code or PIN. */
export async function wrapVaultKey(
  vaultKey: VaultKey,
  wrappingSecret: string,
  saltB64: string,
  iterations = PBKDF2_ITERATIONS_DEFAULT,
): Promise<{ ciphertext: string; iv: string }> {
  const wrapKey = await deriveKeyMaterial(wrappingSecret, saltB64, iterations);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipherBuf = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv as BufferSource }, wrapKey, vaultKey.raw);
  return { ciphertext: toB64(cipherBuf), iv: toB64(iv) };
}

export async function unwrapVaultKey(
  wrappingSecret: string,
  saltB64: string,
  ciphertext: string,
  iv: string,
  iterations = PBKDF2_ITERATIONS_DEFAULT,
): Promise<VaultKey> {
  const wrapKey = await deriveKeyMaterial(wrappingSecret, saltB64, iterations);
  const rawKey = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: fromB64(iv) as BufferSource },
    wrapKey,
    fromB64(ciphertext) as BufferSource,
  );
  const key = await crypto.subtle.importKey("raw", rawKey, "AES-GCM", true, ["encrypt", "decrypt"]);
  return { key, raw: rawKey };
}

export const PBKDF2_ITERATIONS = PBKDF2_ITERATIONS_DEFAULT;

// --------------------------------------------------------------------------
// Secure password generator
// --------------------------------------------------------------------------

const CHARSETS = {
  upper: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
  lower: "abcdefghijklmnopqrstuvwxyz",
  numbers: "0123456789",
  symbols: "!@#$%^&*()_+-=[]{}|;:,.<>?",
};
const SIMILAR = /[il1LoO0]/g;

export type PasswordOptions = {
  length: number;
  upper: boolean;
  lower: boolean;
  numbers: boolean;
  symbols: boolean;
  excludeSimilar: boolean;
};

export function generateSecurePassword(opts: PasswordOptions): string {
  let pool = "";
  if (opts.upper) pool += CHARSETS.upper;
  if (opts.lower) pool += CHARSETS.lower;
  if (opts.numbers) pool += CHARSETS.numbers;
  if (opts.symbols) pool += CHARSETS.symbols;
  if (opts.excludeSimilar) pool = pool.replace(SIMILAR, "");
  if (!pool) pool = CHARSETS.lower;

  const length = Math.min(Math.max(opts.length, 4), 128);
  const values = crypto.getRandomValues(new Uint32Array(length));
  let result = "";
  for (let i = 0; i < length; i++) {
    result += pool[values[i] % pool.length];
  }
  return result;
}

export function passwordStrength(pw: string): { score: number; label: string } {
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (pw.length >= 16) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const labels = ["Very Weak", "Weak", "Fair", "Good", "Strong", "Very Strong", "Excellent"];
  return { score, label: labels[Math.min(score, labels.length - 1)] };
}
