export const SESSION_COOKIE = "sv_session";
export const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days
export const VAULT_UNLOCK_COOKIE = "sv_vault_unlocked";

export const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "gohan.beast.heroic@gmail.com").toLowerCase();

export const ACCOUNT_STATUS = {
  ACTIVE: "active",
  INACTIVE: "inactive",
  SUSPENDED: "suspended",
  DEACTIVATED: "deactivated",
  PENDING_VERIFICATION: "pending_verification",
} as const;

export type AccountStatus = (typeof ACCOUNT_STATUS)[keyof typeof ACCOUNT_STATUS];

export const ACCOUNT_STATUS_LABELS: Record<string, string> = {
  active: "Active — account in good standing and recently used",
  inactive: "Inactive — account has not been used recently, access unaffected",
  suspended: "Suspended — access blocked by an administrator",
  deactivated: "Deactivated — user chose to temporarily disable their account",
  pending_verification: "Pending Verification — email not yet confirmed",
};

export const VAULT_ITEM_TYPES = [
  "email",
  "social",
  "website",
  "device",
  "note",
  "custom",
  "wifi",
  "license",
  "server",
  "api_key",
  "recovery_code",
] as const;

export type VaultItemType = (typeof VAULT_ITEM_TYPES)[number];

export const FINANCE_TX_TYPES = ["income", "expense", "transfer", "refund", "adjustment"] as const;

export const DEFAULT_EXPENSE_CATEGORIES = [
  "Food", "Rent", "Electricity", "Internet", "Mobile", "Transport", "Shopping",
  "Education", "Medical", "Subscriptions", "Family", "Business", "Other",
];

export const DEFAULT_INCOME_CATEGORIES = [
  "Salary", "Freelance", "Business", "Online Earnings", "Investment", "Rental", "Other",
];
