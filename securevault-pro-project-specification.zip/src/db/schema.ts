import {
  pgTable,
  uuid,
  text,
  varchar,
  boolean,
  timestamp,
  integer,
  numeric,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ============================================================================
// USERS & AUTH
// ============================================================================

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: varchar("email", { length: 320 }).notNull(),
    emailLower: varchar("email_lower", { length: 320 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    role: varchar("role", { length: 20 }).notNull().default("user"), // user | admin
    status: varchar("status", { length: 30 }).notNull().default("pending_verification"),
    // active | inactive | suspended | deactivated | pending_verification
    emailVerified: boolean("email_verified").notNull().default(false),
    twoFactorEnabled: boolean("two_factor_enabled").notNull().default(false),
    twoFactorSecret: text("two_factor_secret"),
    failedLoginAttempts: integer("failed_login_attempts").notNull().default(0),
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    lastActivityAt: timestamp("last_activity_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    deactivatedAt: timestamp("deactivated_at", { withTimezone: true }),
    deletionRequestedAt: timestamp("deletion_requested_at", { withTimezone: true }),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => [uniqueIndex("users_email_lower_idx").on(t.emailLower)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    tokenHash: varchar("token_hash", { length: 128 }).notNull(),
    userAgent: text("user_agent"),
    ipAddress: varchar("ip_address", { length: 64 }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastUsedAt: timestamp("last_used_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
  },
  (t) => [
    uniqueIndex("sessions_token_hash_idx").on(t.tokenHash),
    index("sessions_user_id_idx").on(t.userId),
  ],
);

export const verificationTokens = pgTable(
  "verification_tokens",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 30 }).notNull(), // email_verify | password_reset | email_change
    tokenHash: varchar("token_hash", { length: 128 }).notNull(),
    metadata: jsonb("metadata"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("verification_tokens_hash_idx").on(t.tokenHash),
    index("verification_tokens_user_idx").on(t.userId),
  ],
);

export const loginHistory = pgTable(
  "login_history",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
    email: varchar("email", { length: 320 }),
    success: boolean("success").notNull(),
    reason: varchar("reason", { length: 100 }),
    ipAddress: varchar("ip_address", { length: 64 }),
    userAgent: text("user_agent"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("login_history_user_idx").on(t.userId)],
);

export const userSettings = pgTable("user_settings", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  theme: varchar("theme", { length: 20 }).notNull().default("dark"),
  currency: varchar("currency", { length: 10 }).notNull().default("USD"),
  dateFormat: varchar("date_format", { length: 20 }).notNull().default("MM/DD/YYYY"),
  autoLockMinutes: integer("auto_lock_minutes").notNull().default(5),
  financeLockEnabled: boolean("finance_lock_enabled").notNull().default(false),
  notificationPrefs: jsonb("notification_prefs"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ============================================================================
// VAULT (zero-knowledge encrypted)
// ============================================================================

export const vaultSetup = pgTable("vault_setup", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  salt: text("salt").notNull(), // base64 PBKDF2 salt
  kdfIterations: integer("kdf_iterations").notNull().default(310000),
  verifierHash: text("verifier_hash").notNull(), // bcrypt hash of client-derived verifier (server never sees vault key/password)
  recoveryCiphertext: text("recovery_ciphertext"), // vault key wrapped by recovery code (client-side encrypted)
  recoveryIv: text("recovery_iv"),
  recoverySalt: text("recovery_salt"),
  recoveryVerifierHash: text("recovery_verifier_hash"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const vaultCategories = pgTable(
  "vault_categories",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 100 }).notNull(),
    icon: varchar("icon", { length: 50 }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("vault_categories_user_idx").on(t.userId)],
);

export const vaultItems = pgTable(
  "vault_items",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 30 }).notNull(),
    // email | social | website | device | note | custom | wifi | license | server | api_key | recovery_code
    categoryId: uuid("category_id").references(() => vaultCategories.id, { onDelete: "set null" }),
    ciphertext: text("ciphertext").notNull(), // base64 AES-256-GCM ciphertext of full JSON payload
    iv: text("iv").notNull(), // base64 nonce
    encVersion: integer("enc_version").notNull().default(1),
    favorite: boolean("favorite").notNull().default(false),
    archived: boolean("archived").notNull().default(false),
    sizeBytes: integer("size_bytes").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => [
    index("vault_items_user_idx").on(t.userId),
    index("vault_items_user_type_idx").on(t.userId, t.type),
  ],
);

// ============================================================================
// FINANCE
// ============================================================================

export const financeAccounts = pgTable(
  "finance_accounts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 100 }).notNull(),
    type: varchar("type", { length: 30 }).notNull().default("wallet"), // bank | cash | wallet | card | other
    currency: varchar("currency", { length: 10 }).notNull().default("USD"),
    startingBalance: numeric("starting_balance", { precision: 14, scale: 2 }).notNull().default("0"),
    archived: boolean("archived").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("finance_accounts_user_idx").on(t.userId)],
);

export const financeCategories = pgTable(
  "finance_categories",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }), // null = global default
    name: varchar("name", { length: 100 }).notNull(),
    type: varchar("type", { length: 20 }).notNull(), // income | expense
    icon: varchar("icon", { length: 50 }),
    isDefault: boolean("is_default").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("finance_categories_user_idx").on(t.userId)],
);

export const financeTransactions = pgTable(
  "finance_transactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 20 }).notNull(), // income | expense | transfer | refund | adjustment
    title: varchar("title", { length: 200 }).notNull(),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 10 }).notNull().default("USD"),
    categoryId: uuid("category_id").references(() => financeCategories.id, { onDelete: "set null" }),
    accountId: uuid("account_id").references(() => financeAccounts.id, { onDelete: "set null" }),
    transferToAccountId: uuid("transfer_to_account_id").references(() => financeAccounts.id, { onDelete: "set null" }),
    paymentMethod: varchar("payment_method", { length: 50 }),
    date: timestamp("date", { withTimezone: true }).notNull(),
    notes: text("notes"),
    hasReceipt: boolean("has_receipt").notNull().default(false),
    receiptNote: varchar("receipt_note", { length: 200 }),
    recurringId: uuid("recurring_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => [
    index("finance_tx_user_idx").on(t.userId),
    index("finance_tx_user_date_idx").on(t.userId, t.date),
  ],
);

export const financeBudgets = pgTable(
  "finance_budgets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 100 }).notNull(),
    categoryId: uuid("category_id").references(() => financeCategories.id, { onDelete: "set null" }),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    month: integer("month").notNull(), // 1-12
    year: integer("year").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => [index("finance_budgets_user_idx").on(t.userId)],
);

export const savingsGoals = pgTable(
  "savings_goals",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 150 }).notNull(),
    targetAmount: numeric("target_amount", { precision: 14, scale: 2 }).notNull(),
    currentAmount: numeric("current_amount", { precision: 14, scale: 2 }).notNull().default("0"),
    targetDate: timestamp("target_date", { withTimezone: true }),
    notes: text("notes"),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => [index("savings_goals_user_idx").on(t.userId)],
);

export const recurringTransactions = pgTable(
  "recurring_transactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 20 }).notNull(), // income | expense
    title: varchar("title", { length: 200 }).notNull(),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 10 }).notNull().default("USD"),
    categoryId: uuid("category_id").references(() => financeCategories.id, { onDelete: "set null" }),
    accountId: uuid("account_id").references(() => financeAccounts.id, { onDelete: "set null" }),
    paymentMethod: varchar("payment_method", { length: 50 }),
    frequency: varchar("frequency", { length: 20 }).notNull(), // daily | weekly | monthly | yearly
    startDate: timestamp("start_date", { withTimezone: true }).notNull(),
    nextRunDate: timestamp("next_run_date", { withTimezone: true }).notNull(),
    lastProcessedDate: timestamp("last_processed_date", { withTimezone: true }),
    notes: text("notes"),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => [index("recurring_tx_user_idx").on(t.userId)],
);

// ============================================================================
// RECOVERY (vault recovery codes - hashed, one-time use)
// ============================================================================

export const recoveryMethods = pgTable(
  "recovery_methods",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 30 }).notNull().default("vault_recovery_code"),
    codeHash: text("code_hash").notNull(),
    used: boolean("used").notNull().default(false),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("recovery_methods_user_idx").on(t.userId)],
);

// ============================================================================
// BACKUPS
// ============================================================================

export const backups = pgTable(
  "backups",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    version: integer("version").notNull().default(1),
    label: varchar("label", { length: 150 }),
    payload: text("payload").notNull(), // JSON (contains encrypted vault payloads + finance snapshot)
    sizeBytes: integer("size_bytes").notNull(),
    checksum: varchar("checksum", { length: 128 }).notNull(),
    containsVault: boolean("contains_vault").notNull().default(true),
    containsFinance: boolean("contains_finance").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => [index("backups_user_idx").on(t.userId)],
);

// ============================================================================
// ADMIN / AUDIT
// ============================================================================

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    actorUserId: uuid("actor_user_id"),
    actorRole: varchar("actor_role", { length: 20 }),
    action: varchar("action", { length: 100 }).notNull(),
    targetUserId: uuid("target_user_id"),
    metadata: jsonb("metadata"),
    ipAddress: varchar("ip_address", { length: 64 }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("audit_logs_actor_idx").on(t.actorUserId),
    index("audit_logs_target_idx").on(t.targetUserId),
    index("audit_logs_created_idx").on(t.createdAt),
  ],
);

export const adminSettings = pgTable("admin_settings", {
  id: integer("id").primaryKey().default(1),
  maxVaultItems: integer("max_vault_items").notNull().default(2000),
  maxSecureNotes: integer("max_secure_notes").notNull().default(1000),
  maxBackupSizeBytes: integer("max_backup_size_bytes").notNull().default(10 * 1024 * 1024),
  maxFileUploadBytes: integer("max_file_upload_bytes").notNull().default(5 * 1024 * 1024),
  maxTotalStorageBytes: integer("max_total_storage_bytes").notNull().default(50 * 1024 * 1024),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  updatedBy: uuid("updated_by"),
});
