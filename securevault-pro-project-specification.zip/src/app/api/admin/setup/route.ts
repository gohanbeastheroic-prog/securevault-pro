import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { ADMIN_EMAIL } from "@/lib/constants";
import { recordAudit } from "@/lib/audit";

const schema = z.object({ setupSecret: z.string().min(1) });

/**
 * Secure, explicit first-time administrator provisioning.
 *
 * Requirements enforced server-side:
 *  - The caller must already be authenticated as the designated admin email.
 *  - The account's email must be verified (proves ownership).
 *  - Two-factor authentication must already be enabled on the account.
 *  - The request must present ADMIN_SETUP_SECRET, a value only known to the
 *    operator who configured the server environment — never hardcoded in source.
 */
export async function POST(req: NextRequest) {
  try {
    const sessionUser = await requireUser();
    const configuredSecret = process.env.ADMIN_SETUP_SECRET;

    if (!configuredSecret) {
      throw new ApiError(
        "Administrator setup is not configured on this server. Set ADMIN_SETUP_SECRET in the environment to enable provisioning.",
        503,
      );
    }

    if (sessionUser.email.toLowerCase() !== ADMIN_EMAIL) {
      throw new ApiError("This account is not eligible for administrator provisioning.", 403);
    }

    const { setupSecret } = await parseBody(req, schema);
    if (setupSecret !== configuredSecret) {
      throw new ApiError("Invalid administrator setup secret.", 403);
    }

    const [user] = await db.select().from(users).where(eq(users.id, sessionUser.id)).limit(1);
    if (!user) throw new ApiError("Account not found.", 404);
    if (!user.emailVerified) throw new ApiError("Verify your email address before requesting admin access.", 403);
    if (!user.twoFactorEnabled) {
      throw new ApiError("Enable two-factor authentication on this account before requesting admin access.", 403);
    }

    await db.update(users).set({ role: "admin" }).where(eq(users.id, user.id));
    await recordAudit({ actorUserId: user.id, actorRole: "admin", action: "admin.provisioned", targetUserId: user.id });

    return NextResponse.json({ message: "Administrator access granted." });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function GET() {
  try {
    const sessionUser = await requireUser();
    return NextResponse.json({
      eligible: sessionUser.email.toLowerCase() === ADMIN_EMAIL,
      alreadyAdmin: sessionUser.role === "admin",
      twoFactorEnabled: sessionUser.twoFactorEnabled,
      emailVerified: sessionUser.emailVerified,
      serverConfigured: Boolean(process.env.ADMIN_SETUP_SECRET),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
