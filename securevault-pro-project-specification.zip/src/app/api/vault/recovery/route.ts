import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { vaultSetup, vaultItems } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { hashSecret, verifySecret } from "@/lib/crypto-server";
import { rateLimit } from "@/lib/rate-limit";
import { recordAudit } from "@/lib/audit";

const setupSchema = z.object({
  recoveryCiphertext: z.string().min(1),
  recoveryIv: z.string().min(1),
  recoverySalt: z.string().min(1),
  recoveryVerifier: z.string().min(10),
});

// Fetch wrapped recovery material (useless without the user's recovery code).
export async function GET() {
  try {
    const user = await requireUser();
    const [row] = await db.select().from(vaultSetup).where(eq(vaultSetup.userId, user.id)).limit(1);
    if (!row || !row.recoveryCiphertext) return NextResponse.json({ available: false });

    return NextResponse.json({
      available: true,
      recoveryCiphertext: row.recoveryCiphertext,
      recoveryIv: row.recoveryIv,
      recoverySalt: row.recoverySalt,
    });
  } catch (err) {
    return handleApiError(err);
  }
}

// Regenerate / configure a recovery code wrapping (server never sees the plaintext code).
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, setupSchema);
    const recoveryVerifierHash = await hashSecret(body.recoveryVerifier);

    const [row] = await db.select({ userId: vaultSetup.userId }).from(vaultSetup).where(eq(vaultSetup.userId, user.id)).limit(1);
    if (!row) throw new ApiError("Vault has not been set up yet.", 404);

    await db
      .update(vaultSetup)
      .set({
        recoveryCiphertext: body.recoveryCiphertext,
        recoveryIv: body.recoveryIv,
        recoverySalt: body.recoverySalt,
        recoveryVerifierHash,
        updatedAt: new Date(),
      })
      .where(eq(vaultSetup.userId, user.id));

    await recordAudit({ actorUserId: user.id, action: "vault.recovery_code_regenerated" });
    return NextResponse.json({ message: "Recovery code configured. Store it somewhere safe — it will not be shown again." });
  } catch (err) {
    return handleApiError(err);
  }
}

const resetSchema = z.object({
  recoveryVerifier: z.string().min(10),
  newSalt: z.string().min(10),
  newKdfIterations: z.number().int().min(100000).max(2000000),
  newVerifier: z.string().min(10),
  reencryptedItems: z.array(z.object({ id: z.string().uuid(), ciphertext: z.string(), iv: z.string() })).default([]),
});

// Use the recovery code (verified) to set a brand new master password after re-encrypting locally.
export async function PUT(req: NextRequest) {
  try {
    const user = await requireUser();
    if (!rateLimit(`vault-recovery:${user.id}`, 5, 15 * 60 * 1000)) {
      throw new ApiError("Too many recovery attempts. Please wait before trying again.", 429);
    }

    const body = await parseBody(req, resetSchema);
    const [row] = await db.select().from(vaultSetup).where(eq(vaultSetup.userId, user.id)).limit(1);
    if (!row || !row.recoveryVerifierHash) throw new ApiError("No recovery method is configured for this vault.", 404);

    const valid = await verifySecret(body.recoveryVerifier, row.recoveryVerifierHash);
    if (!valid) {
      await recordAudit({ actorUserId: user.id, action: "vault.recovery_failed" });
      throw new ApiError("Incorrect recovery code.", 401);
    }

    const newVerifierHash = await hashSecret(body.newVerifier);

    await db.transaction(async (tx) => {
      await tx
        .update(vaultSetup)
        .set({
          salt: body.newSalt,
          kdfIterations: body.newKdfIterations,
          verifierHash: newVerifierHash,
          // Consume the recovery code — user must generate a new one.
          recoveryCiphertext: null,
          recoveryIv: null,
          recoverySalt: null,
          recoveryVerifierHash: null,
          updatedAt: new Date(),
        })
        .where(eq(vaultSetup.userId, user.id));

      for (const item of body.reencryptedItems) {
        await tx
          .update(vaultItems)
          .set({ ciphertext: item.ciphertext, iv: item.iv, updatedAt: new Date() })
          .where(and(eq(vaultItems.id, item.id), eq(vaultItems.userId, user.id)));
      }
    });

    await recordAudit({ actorUserId: user.id, action: "vault.recovered" });
    return NextResponse.json({ message: "Vault recovered and master password reset. Please generate a new recovery code." });
  } catch (err) {
    return handleApiError(err);
  }
}
