import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { vaultItems, adminSettings } from "@/db/schema";
import { and, desc, eq, isNull, isNotNull } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { vaultItemSchema } from "@/lib/validation";
import { recordAudit } from "@/lib/audit";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const type = searchParams.get("type");
    const trashed = searchParams.get("trashed") === "true";
    const favorite = searchParams.get("favorite") === "true";
    const archived = searchParams.get("archived") === "true";

    const conditions = [eq(vaultItems.userId, user.id)];
    conditions.push(trashed ? isNotNull(vaultItems.deletedAt) : isNull(vaultItems.deletedAt));
    if (type) conditions.push(eq(vaultItems.type, type));
    if (favorite) conditions.push(eq(vaultItems.favorite, true));
    if (archived) conditions.push(eq(vaultItems.archived, true));

    const rows = await db
      .select()
      .from(vaultItems)
      .where(and(...conditions))
      .orderBy(desc(vaultItems.updatedAt));

    return NextResponse.json({ items: rows });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, vaultItemSchema);

    const [settings] = await db.select().from(adminSettings).limit(1);
    const maxItems = settings?.maxVaultItems ?? 2000;

    const countRows = await db
      .select({ id: vaultItems.id })
      .from(vaultItems)
      .where(and(eq(vaultItems.userId, user.id), isNull(vaultItems.deletedAt)));

    if (countRows.length >= maxItems) {
      throw new ApiError(`Vault item limit reached (${maxItems}). Delete unused items or contact an administrator.`, 409);
    }

    const [item] = await db
      .insert(vaultItems)
      .values({
        userId: user.id,
        type: body.type,
        categoryId: body.categoryId || null,
        ciphertext: body.ciphertext,
        iv: body.iv,
        favorite: body.favorite ?? false,
        archived: body.archived ?? false,
        sizeBytes: body.sizeBytes,
      })
      .returning();

    await recordAudit({ actorUserId: user.id, action: "vault.item_created", metadata: { type: body.type } });

    return NextResponse.json({ item });
  } catch (err) {
    return handleApiError(err);
  }
}
