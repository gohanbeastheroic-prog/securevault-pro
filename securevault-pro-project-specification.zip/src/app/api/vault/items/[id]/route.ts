import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { vaultItems } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { vaultItemUpdateSchema } from "@/lib/validation";
import { recordAudit } from "@/lib/audit";
import { z } from "zod";

async function getOwnedItem(id: string, userId: string) {
  const [item] = await db.select().from(vaultItems).where(and(eq(vaultItems.id, id), eq(vaultItems.userId, userId))).limit(1);
  if (!item) throw new ApiError("Vault item not found.", 404);
  return item;
}

const patchSchema = vaultItemUpdateSchema.extend({
  restore: z.boolean().optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    await getOwnedItem(id, user.id);

    const body = await parseBody(req, patchSchema);
    const update: Record<string, unknown> = { updatedAt: new Date() };

    if (body.ciphertext !== undefined) update.ciphertext = body.ciphertext;
    if (body.iv !== undefined) update.iv = body.iv;
    if (body.categoryId !== undefined) update.categoryId = body.categoryId;
    if (body.favorite !== undefined) update.favorite = body.favorite;
    if (body.archived !== undefined) update.archived = body.archived;
    if (body.sizeBytes !== undefined) update.sizeBytes = body.sizeBytes;
    if (body.restore) update.deletedAt = null;

    const [updated] = await db.update(vaultItems).set(update).where(and(eq(vaultItems.id, id), eq(vaultItems.userId, user.id))).returning();

    await recordAudit({ actorUserId: user.id, action: body.restore ? "vault.item_restored" : "vault.item_updated" });

    return NextResponse.json({ item: updated });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    const item = await getOwnedItem(id, user.id);

    const { searchParams } = new URL(req.url);
    const permanent = searchParams.get("permanent") === "true";

    if (permanent) {
      if (!item.deletedAt) throw new ApiError("Move the item to trash before permanently deleting it.", 400);
      await db.delete(vaultItems).where(and(eq(vaultItems.id, id), eq(vaultItems.userId, user.id)));
      await recordAudit({ actorUserId: user.id, action: "vault.item_permanently_deleted" });
      return NextResponse.json({ message: "Item permanently deleted." });
    }

    await db.update(vaultItems).set({ deletedAt: new Date() }).where(and(eq(vaultItems.id, id), eq(vaultItems.userId, user.id)));
    await recordAudit({ actorUserId: user.id, action: "vault.item_trashed" });
    return NextResponse.json({ message: "Item moved to trash." });
  } catch (err) {
    return handleApiError(err);
  }
}
