import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { vaultSetup } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { vaultSetupSchema } from "@/lib/validation";
import { hashSecret } from "@/lib/crypto-server";
import { recordAudit } from "@/lib/audit";

export async function GET() {
  try {
    const user = await requireUser();
    const [row] = await db.select().from(vaultSetup).where(eq(vaultSetup.userId, user.id)).limit(1);
    if (!row) return NextResponse.json({ configured: false });

    return NextResponse.json({
      configured: true,
      salt: row.salt,
      kdfIterations: row.kdfIterations,
      hasRecovery: Boolean(row.recoveryCiphertext),
    });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, vaultSetupSchema);

    const [existing] = await db.select({ userId: vaultSetup.userId }).from(vaultSetup).where(eq(vaultSetup.userId, user.id)).limit(1);
    if (existing) throw new ApiError("A vault has already been created for this account.", 409);

    const verifierHash = await hashSecret(body.verifier);
    const recoveryVerifierHash = body.recoveryVerifier ? await hashSecret(body.recoveryVerifier) : null;

    await db.insert(vaultSetup).values({
      userId: user.id,
      salt: body.salt,
      kdfIterations: body.kdfIterations,
      verifierHash,
      recoveryCiphertext: body.recoveryCiphertext || null,
      recoveryIv: body.recoveryIv || null,
      recoverySalt: body.recoverySalt || null,
      recoveryVerifierHash,
    });

    await recordAudit({ actorUserId: user.id, action: "vault.created" });

    return NextResponse.json({ message: "Vault created successfully." });
  } catch (err) {
    return handleApiError(err);
  }
}
