import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { vaultCategories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { vaultCategorySchema } from "@/lib/validation";

export async function GET() {
  try {
    const user = await requireUser();
    const rows = await db.select().from(vaultCategories).where(eq(vaultCategories.userId, user.id));
    return NextResponse.json({ categories: rows });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, vaultCategorySchema);
    const [category] = await db.insert(vaultCategories).values({ userId: user.id, name: body.name, icon: body.icon }).returning();
    return NextResponse.json({ category });
  } catch (err) {
    return handleApiError(err);
  }
}
