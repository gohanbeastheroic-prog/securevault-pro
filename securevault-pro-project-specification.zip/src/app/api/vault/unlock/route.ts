import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { vaultSetup } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { vaultUnlockSchema } from "@/lib/validation";
import { verifySecret } from "@/lib/crypto-server";
import { rateLimit } from "@/lib/rate-limit";
import { recordAudit } from "@/lib/audit";

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();

    if (!rateLimit(`vault-unlock:${user.id}`, 8, 10 * 60 * 1000)) {
      throw new ApiError("Too many vault unlock attempts. Please wait before trying again.", 429);
    }

    const { verifier } = await parseBody(req, vaultUnlockSchema);
    const [row] = await db.select().from(vaultSetup).where(eq(vaultSetup.userId, user.id)).limit(1);
    if (!row) throw new ApiError("Vault has not been set up yet.", 404);

    const valid = await verifySecret(verifier, row.verifierHash);
    if (!valid) {
      await recordAudit({ actorUserId: user.id, action: "vault.unlock_failed" });
      throw new ApiError("Incorrect vault master password.", 401);
    }

    await recordAudit({ actorUserId: user.id, action: "vault.unlocked" });
    return NextResponse.json({ message: "Vault unlocked." });
  } catch (err) {
    return handleApiError(err);
  }
}
