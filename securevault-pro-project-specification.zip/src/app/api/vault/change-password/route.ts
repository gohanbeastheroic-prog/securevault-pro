import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { vaultSetup, vaultItems } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { vaultChangePasswordSchema } from "@/lib/validation";
import { hashSecret, verifySecret } from "@/lib/crypto-server";
import { recordAudit } from "@/lib/audit";

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, vaultChangePasswordSchema);

    const [row] = await db.select().from(vaultSetup).where(eq(vaultSetup.userId, user.id)).limit(1);
    if (!row) throw new ApiError("Vault has not been set up yet.", 404);

    const valid = await verifySecret(body.oldVerifier, row.verifierHash);
    if (!valid) throw new ApiError("Current vault master password is incorrect.", 401);

    const newVerifierHash = await hashSecret(body.newVerifier);

    await db.transaction(async (tx) => {
      await tx
        .update(vaultSetup)
        .set({
          salt: body.newSalt,
          kdfIterations: body.newKdfIterations,
          verifierHash: newVerifierHash,
          updatedAt: new Date(),
        })
        .where(eq(vaultSetup.userId, user.id));

      for (const item of body.reencryptedItems) {
        await tx
          .update(vaultItems)
          .set({ ciphertext: item.ciphertext, iv: item.iv, updatedAt: new Date() })
          .where(and(eq(vaultItems.id, item.id), eq(vaultItems.userId, user.id)));
      }
    });

    await recordAudit({ actorUserId: user.id, action: "vault.master_password_changed", metadata: { reencryptedCount: body.reencryptedItems.length } });

    return NextResponse.json({ message: "Vault master password updated successfully." });
  } catch (err) {
    return handleApiError(err);
  }
}
