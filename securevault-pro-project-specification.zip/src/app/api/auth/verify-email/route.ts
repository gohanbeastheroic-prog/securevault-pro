import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { verificationTokens, users } from "@/db/schema";
import { and, eq, isNull, gt } from "drizzle-orm";
import { hashToken } from "@/lib/crypto-server";
import { parseBody, handleApiError } from "@/lib/api-utils";
import { ApiError } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";

const schema = z.object({ token: z.string().min(10) });

export async function POST(req: NextRequest) {
  try {
    const { token } = await parseBody(req, schema);
    const tokenHash = hashToken(token);
    const now = new Date();

    const [record] = await db
      .select()
      .from(verificationTokens)
      .where(
        and(
          eq(verificationTokens.tokenHash, tokenHash),
          isNull(verificationTokens.usedAt),
          gt(verificationTokens.expiresAt, now),
        ),
      )
      .limit(1);

    if (!record) throw new ApiError("This verification link is invalid or has expired.", 400);

    await db.update(verificationTokens).set({ usedAt: now }).where(eq(verificationTokens.id, record.id));

    if (record.type === "email_verify") {
      const [user] = await db.select().from(users).where(eq(users.id, record.userId)).limit(1);
      if (!user) throw new ApiError("Account not found.", 404);
      await db
        .update(users)
        .set({
          emailVerified: true,
          status: user.status === "pending_verification" ? "active" : user.status,
        })
        .where(eq(users.id, record.userId));
      await recordAudit({ actorUserId: record.userId, action: "user.email_verified" });
      return NextResponse.json({ message: "Email verified successfully. You can now sign in." });
    }

    if (record.type === "email_change") {
      const metadata = record.metadata as { newEmail?: string } | null;
      if (!metadata?.newEmail) throw new ApiError("Invalid email change request.", 400);
      await db
        .update(users)
        .set({ email: metadata.newEmail, emailLower: metadata.newEmail.toLowerCase() })
        .where(eq(users.id, record.userId));
      await recordAudit({ actorUserId: record.userId, action: "user.email_changed" });
      return NextResponse.json({ message: "Email address updated successfully." });
    }

    throw new ApiError("Unsupported verification type.", 400);
  } catch (err) {
    return handleApiError(err);
  }
}
