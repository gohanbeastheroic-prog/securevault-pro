import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { and, desc, eq, gt, isNull, ne } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError } from "@/lib/api-utils";
import { cookies } from "next/headers";
import { SESSION_COOKIE } from "@/lib/constants";
import { hashToken } from "@/lib/crypto-server";
import { recordAudit } from "@/lib/audit";

export async function GET() {
  try {
    const user = await requireUser();
    const cookieStore = await cookies();
    const currentToken = cookieStore.get(SESSION_COOKIE)?.value;
    const currentHash = currentToken ? hashToken(currentToken) : "";

    const rows = await db
      .select()
      .from(sessions)
      .where(and(eq(sessions.userId, user.id), isNull(sessions.revokedAt), gt(sessions.expiresAt, new Date())))
      .orderBy(desc(sessions.lastUsedAt));

    return NextResponse.json({
      sessions: rows.map((s) => ({
        id: s.id,
        userAgent: s.userAgent,
        ipAddress: s.ipAddress,
        createdAt: s.createdAt,
        lastUsedAt: s.lastUsedAt,
        expiresAt: s.expiresAt,
        current: s.tokenHash === currentHash,
      })),
    });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const all = searchParams.get("all") === "true";
    const id = searchParams.get("id");

    const cookieStore = await cookies();
    const currentToken = cookieStore.get(SESSION_COOKIE)?.value;
    const currentHash = currentToken ? hashToken(currentToken) : "";

    if (all) {
      await db
        .update(sessions)
        .set({ revokedAt: new Date() })
        .where(and(eq(sessions.userId, user.id), ne(sessions.tokenHash, currentHash)));
      await recordAudit({ actorUserId: user.id, actorRole: user.role, action: "user.sessions_revoked_all" });
      return NextResponse.json({ message: "All other sessions have been signed out." });
    }

    if (id) {
      await db.update(sessions).set({ revokedAt: new Date() }).where(and(eq(sessions.id, id), eq(sessions.userId, user.id)));
      await recordAudit({ actorUserId: user.id, actorRole: user.role, action: "user.session_revoked" });
      return NextResponse.json({ message: "Session revoked." });
    }

    return NextResponse.json({ error: "Missing session id." }, { status: 400 });
  } catch (err) {
    return handleApiError(err);
  }
}


