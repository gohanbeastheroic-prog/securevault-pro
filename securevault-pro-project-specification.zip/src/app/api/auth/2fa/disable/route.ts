import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { verifyPassword } from "@/lib/crypto-server";
import { recordAudit } from "@/lib/audit";

const schema = z.object({ currentPassword: z.string().min(1) });

export async function POST(req: NextRequest) {
  try {
    const sessionUser = await requireUser();
    const { currentPassword } = await parseBody(req, schema);
    const [user] = await db.select().from(users).where(eq(users.id, sessionUser.id)).limit(1);
    if (!user) throw new ApiError("Account not found.", 404);

    if (user.role === "admin") {
      throw new ApiError("Two-factor authentication is mandatory for administrator accounts and cannot be disabled.", 403);
    }

    const valid = await verifyPassword(currentPassword, user.passwordHash);
    if (!valid) throw new ApiError("Current password is incorrect.", 401);

    await db.update(users).set({ twoFactorEnabled: false, twoFactorSecret: null }).where(eq(users.id, user.id));
    await recordAudit({ actorUserId: user.id, actorRole: user.role, action: "user.2fa_disabled" });

    return NextResponse.json({ message: "Two-factor authentication disabled." });
  } catch (err) {
    return handleApiError(err);
  }
}
