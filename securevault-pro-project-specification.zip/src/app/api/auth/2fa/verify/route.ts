import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { verifyTotpToken } from "@/lib/totp";
import { recordAudit } from "@/lib/audit";

const schema = z.object({ token: z.string().min(6).max(10) });

export async function POST(req: NextRequest) {
  try {
    const sessionUser = await requireUser();
    const { token } = await parseBody(req, schema);

    const [user] = await db.select().from(users).where(eq(users.id, sessionUser.id)).limit(1);
    if (!user || !user.twoFactorSecret) throw new ApiError("Two-factor setup was not started.", 400);

    const valid = await verifyTotpToken(token, user.twoFactorSecret);
    if (!valid) throw new ApiError("Invalid authentication code.", 401);

    await db.update(users).set({ twoFactorEnabled: true }).where(eq(users.id, user.id));
    await recordAudit({ actorUserId: user.id, actorRole: user.role, action: "user.2fa_enabled" });

    return NextResponse.json({ message: "Two-factor authentication enabled." });
  } catch (err) {
    return handleApiError(err);
  }
}
