import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError } from "@/lib/api-utils";
import { createTotpSecret, totpProvisioningUri } from "@/lib/totp";

// Step 1: generate a pending secret + QR provisioning URI (not yet enabled until verified).
export async function POST() {
  try {
    const sessionUser = await requireUser();
    const [user] = await db.select().from(users).where(eq(users.id, sessionUser.id)).limit(1);
    if (!user) throw new ApiError("Account not found.", 404);

    const secret = createTotpSecret();
    // Store as a pending secret; it only becomes active once confirmed via /verify.
    await db.update(users).set({ twoFactorSecret: secret, twoFactorEnabled: false }).where(eq(users.id, user.id));

    const uri = totpProvisioningUri(user.email, secret);
    return NextResponse.json({ secret, uri });
  } catch (err) {
    return handleApiError(err);
  }
}
