import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, verificationTokens, userSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { registerSchema } from "@/lib/validation";
import { parseBody, handleApiError } from "@/lib/api-utils";
import { hashPassword, generateToken, hashToken } from "@/lib/crypto-server";
import { sendEmail, verificationEmailHtml } from "@/lib/email";
import { recordAudit } from "@/lib/audit";
import { rateLimit } from "@/lib/rate-limit";
import { getClientIp } from "@/lib/auth";
import { ApiError } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const ip = await getClientIp();
    if (!rateLimit(`register:${ip}`, 8, 10 * 60 * 1000)) {
      throw new ApiError("Too many registration attempts. Please try again later.", 429);
    }

    const { email, password } = await parseBody(req, registerSchema);
    const emailLower = email.toLowerCase();

    const existing = await db.select({ id: users.id }).from(users).where(eq(users.emailLower, emailLower)).limit(1);
    if (existing.length > 0) {
      // Avoid user enumeration: respond success-shaped message either way.
      return NextResponse.json({
        message: "If this email is not already registered, a verification link has been sent.",
      });
    }

    const passwordHash = await hashPassword(password);
    const [user] = await db
      .insert(users)
      .values({ email, emailLower, passwordHash, role: "user", status: "pending_verification" })
      .returning();

    await db.insert(userSettings).values({ userId: user.id });

    const token = generateToken(32);
    await db.insert(verificationTokens).values({
      userId: user.id,
      type: "email_verify",
      tokenHash: hashToken(token),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    });

    const origin = req.nextUrl.origin;
    const link = `${origin}/verify-email?token=${token}`;
    await sendEmail(email, "Verify your SecureVault Pro account", verificationEmailHtml(link));

    await recordAudit({ action: "user.registered", targetUserId: user.id, ipAddress: ip });

    return NextResponse.json({
      message: "Account created. Check your email to verify your account.",
      devVerifyLink: process.env.RESEND_API_KEY ? undefined : link,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
