import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { verificationTokens, users, sessions } from "@/db/schema";
import { and, eq, isNull, gt } from "drizzle-orm";
import { resetPasswordSchema } from "@/lib/validation";
import { parseBody, handleApiError } from "@/lib/api-utils";
import { hashPassword, hashToken } from "@/lib/crypto-server";
import { ApiError } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";

export async function POST(req: NextRequest) {
  try {
    const { token, password } = await parseBody(req, resetPasswordSchema);
    const tokenHash = hashToken(token);
    const now = new Date();

    const [record] = await db
      .select()
      .from(verificationTokens)
      .where(
        and(
          eq(verificationTokens.tokenHash, tokenHash),
          eq(verificationTokens.type, "password_reset"),
          isNull(verificationTokens.usedAt),
          gt(verificationTokens.expiresAt, now),
        ),
      )
      .limit(1);

    if (!record) throw new ApiError("This reset link is invalid or has expired.", 400);

    const passwordHash = await hashPassword(password);
    await db.update(users).set({ passwordHash, failedLoginAttempts: 0, lockedUntil: null }).where(eq(users.id, record.userId));
    await db.update(verificationTokens).set({ usedAt: now }).where(eq(verificationTokens.id, record.id));

    // Revoke all existing sessions for security (does NOT touch the separate vault key).
    await db.update(sessions).set({ revokedAt: now }).where(eq(sessions.userId, record.userId));

    await recordAudit({ actorUserId: record.userId, action: "user.password_reset_completed" });

    return NextResponse.json({
      message: "Password reset successfully. Your vault master password (if configured) is unchanged — sign in and unlock your vault separately.",
    });
  } catch (err) {
    return handleApiError(err);
  }
}
