import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, loginHistory } from "@/db/schema";
import { eq } from "drizzle-orm";
import { loginSchema } from "@/lib/validation";
import { verifyTotpToken } from "@/lib/totp";
import { parseBody, handleApiError } from "@/lib/api-utils";
import { verifyPassword } from "@/lib/crypto-server";
import { createSession, getClientIp, getUserAgent, ApiError } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { rateLimit } from "@/lib/rate-limit";

const MAX_FAILED_ATTEMPTS = 6;
const LOCK_DURATION_MS = 15 * 60 * 1000;

export async function POST(req: NextRequest) {
  const ip = await getClientIp();
  const ua = await getUserAgent();

  try {
    if (!rateLimit(`login:${ip}`, 15, 10 * 60 * 1000)) {
      throw new ApiError("Too many login attempts from this network. Please try again later.", 429);
    }

    const { email, password, totpCode } = await parseBody(req, loginSchema);
    const emailLower = email.toLowerCase();

    if (!rateLimit(`login-email:${emailLower}`, 10, 10 * 60 * 1000)) {
      throw new ApiError("Too many login attempts for this account. Please try again later.", 429);
    }

    const [user] = await db.select().from(users).where(eq(users.emailLower, emailLower)).limit(1);

    const fail = async (reason: string) => {
      await db.insert(loginHistory).values({ userId: user?.id, email, success: false, reason, ipAddress: ip, userAgent: ua });
    };

    if (!user || user.deletedAt) {
      await fail("invalid_credentials");
      throw new ApiError("Invalid email or password.", 401);
    }

    if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
      await fail("account_locked");
      throw new ApiError("This account is temporarily locked due to failed login attempts. Try again later.", 423);
    }

    if (user.status === "suspended") {
      await fail("suspended");
      throw new ApiError("This account has been suspended. Contact support for assistance.", 403);
    }

    if (user.status === "deactivated") {
      await fail("deactivated");
      throw new ApiError("This account has been deactivated. Reactivate it from the login recovery options.", 403);
    }

    const validPassword = await verifyPassword(password, user.passwordHash);
    if (!validPassword) {
      const attempts = user.failedLoginAttempts + 1;
      const lockedUntil = attempts >= MAX_FAILED_ATTEMPTS ? new Date(Date.now() + LOCK_DURATION_MS) : null;
      await db.update(users).set({ failedLoginAttempts: attempts, lockedUntil }).where(eq(users.id, user.id));
      await fail("invalid_credentials");
      throw new ApiError("Invalid email or password.", 401);
    }

    // Mandatory 2FA enforcement for admin role.
    if (user.role === "admin" || user.twoFactorEnabled) {
      if (!user.twoFactorSecret) {
        throw new ApiError("Two-factor authentication is required but not configured for this account.", 403);
      }
      if (!totpCode) {
        return NextResponse.json({ requiresTotp: true, message: "Enter your two-factor authentication code." }, { status: 200 });
      }
      const valid = await verifyTotpToken(totpCode, user.twoFactorSecret);
      if (!valid) {
        await fail("invalid_2fa");
        throw new ApiError("Invalid two-factor authentication code.", 401);
      }
    }

    await db
      .update(users)
      .set({ failedLoginAttempts: 0, lockedUntil: null, lastLoginAt: new Date(), lastActivityAt: new Date() })
      .where(eq(users.id, user.id));

    await db.insert(loginHistory).values({ userId: user.id, email, success: true, reason: "ok", ipAddress: ip, userAgent: ua });

    await createSession(user.id);
    await recordAudit({ actorUserId: user.id, actorRole: user.role, action: "user.login", ipAddress: ip });

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        status: user.status,
        emailVerified: user.emailVerified,
      },
    });
  } catch (err) {
    return handleApiError(err);
  }
}
