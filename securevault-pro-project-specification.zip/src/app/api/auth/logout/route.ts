import { NextResponse } from "next/server";
import { destroySession, getCurrentUser } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";

export async function POST() {
  const user = await getCurrentUser();
  await destroySession();
  if (user) await recordAudit({ actorUserId: user.id, actorRole: user.role, action: "user.logout" });
  return NextResponse.json({ message: "Logged out." });
}
