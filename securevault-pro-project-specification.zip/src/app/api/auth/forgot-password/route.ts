import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, verificationTokens } from "@/db/schema";
import { eq } from "drizzle-orm";
import { forgotPasswordSchema } from "@/lib/validation";
import { parseBody, handleApiError } from "@/lib/api-utils";
import { generateToken, hashToken } from "@/lib/crypto-server";
import { sendEmail, passwordResetEmailHtml } from "@/lib/email";
import { rateLimit } from "@/lib/rate-limit";
import { getClientIp, ApiError } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";

export async function POST(req: NextRequest) {
  try {
    const ip = await getClientIp();
    if (!rateLimit(`forgot-password:${ip}`, 6, 15 * 60 * 1000)) {
      throw new ApiError("Too many requests. Please try again later.", 429);
    }
    const { email } = await parseBody(req, forgotPasswordSchema);
    const emailLower = email.toLowerCase();

    if (!rateLimit(`forgot-password-email:${emailLower}`, 4, 30 * 60 * 1000)) {
      throw new ApiError("Too many requests for this account. Please try again later.", 429);
    }

    const [user] = await db.select().from(users).where(eq(users.emailLower, emailLower)).limit(1);

    let devLink: string | undefined;
    if (user && !user.deletedAt) {
      const token = generateToken(32);
      await db.insert(verificationTokens).values({
        userId: user.id,
        type: "password_reset",
        tokenHash: hashToken(token),
        expiresAt: new Date(Date.now() + 60 * 60 * 1000),
      });
      const link = `${req.nextUrl.origin}/reset-password?token=${token}`;
      await sendEmail(user.email, "Reset your SecureVault Pro password", passwordResetEmailHtml(link));
      await recordAudit({ actorUserId: user.id, action: "user.password_reset_requested", ipAddress: ip });
      if (!process.env.RESEND_API_KEY) devLink = link;
    }

    return NextResponse.json({
      message: "If this email is registered, a password reset link has been sent.",
      devResetLink: devLink,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
