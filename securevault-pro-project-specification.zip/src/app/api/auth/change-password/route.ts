import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, sessions } from "@/db/schema";
import { and, eq, ne } from "drizzle-orm";
import { changePasswordSchema } from "@/lib/validation";
import { parseBody, handleApiError } from "@/lib/api-utils";
import { hashPassword, verifyPassword, hashToken } from "@/lib/crypto-server";
import { requireUser, ApiError } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { cookies } from "next/headers";
import { SESSION_COOKIE } from "@/lib/constants";

export async function POST(req: NextRequest) {
  try {
    const sessionUser = await requireUser();
    const { currentPassword, newPassword } = await parseBody(req, changePasswordSchema);

    const [user] = await db.select().from(users).where(eq(users.id, sessionUser.id)).limit(1);
    if (!user) throw new ApiError("Account not found.", 404);

    const valid = await verifyPassword(currentPassword, user.passwordHash);
    if (!valid) throw new ApiError("Current password is incorrect.", 401);

    const passwordHash = await hashPassword(newPassword);
    await db.update(users).set({ passwordHash }).where(eq(users.id, user.id));

    const cookieStore = await cookies();
    const currentToken = cookieStore.get(SESSION_COOKIE)?.value;
    const currentHash = currentToken ? hashToken(currentToken) : "";

    // Revoke all other sessions, keep the current one active.
    await db
      .update(sessions)
      .set({ revokedAt: new Date() })
      .where(and(eq(sessions.userId, user.id), ne(sessions.tokenHash, currentHash)));

    await recordAudit({ actorUserId: user.id, actorRole: user.role, action: "user.password_changed" });

    return NextResponse.json({ message: "Password updated. Other sessions were signed out for security." });
  } catch (err) {
    return handleApiError(err);
  }
}
