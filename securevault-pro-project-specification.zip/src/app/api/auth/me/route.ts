import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { userSettings, vaultSetup } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ user: null });

  const [settings] = await db.select().from(userSettings).where(eq(userSettings.userId, user.id)).limit(1);
  const [vault] = await db.select({ userId: vaultSetup.userId }).from(vaultSetup).where(eq(vaultSetup.userId, user.id)).limit(1);

  return NextResponse.json({
    user,
    settings: settings || null,
    vaultConfigured: Boolean(vault),
  });
}
