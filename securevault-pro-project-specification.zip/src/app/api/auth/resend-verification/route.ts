import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { users, verificationTokens } from "@/db/schema";
import { eq } from "drizzle-orm";
import { parseBody, handleApiError } from "@/lib/api-utils";
import { generateToken, hashToken } from "@/lib/crypto-server";
import { sendEmail, verificationEmailHtml } from "@/lib/email";
import { rateLimit } from "@/lib/rate-limit";
import { getClientIp, ApiError } from "@/lib/auth";

const schema = z.object({ email: z.string().email() });

export async function POST(req: NextRequest) {
  try {
    const ip = await getClientIp();
    if (!rateLimit(`resend-verify:${ip}`, 5, 10 * 60 * 1000)) {
      throw new ApiError("Too many requests. Please try again later.", 429);
    }
    const { email } = await parseBody(req, schema);
    const [user] = await db.select().from(users).where(eq(users.emailLower, email.toLowerCase())).limit(1);

    if (user && !user.emailVerified) {
      const token = generateToken(32);
      await db.insert(verificationTokens).values({
        userId: user.id,
        type: "email_verify",
        tokenHash: hashToken(token),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      });
      const link = `${req.nextUrl.origin}/verify-email?token=${token}`;
      await sendEmail(user.email, "Verify your SecureVault Pro account", verificationEmailHtml(link));
      return NextResponse.json({
        message: "Verification email sent.",
        devVerifyLink: process.env.RESEND_API_KEY ? undefined : link,
      });
    }

    return NextResponse.json({ message: "If this account exists and is unverified, a new link has been sent." });
  } catch (err) {
    return handleApiError(err);
  }
}
