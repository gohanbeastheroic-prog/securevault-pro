import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, verificationTokens } from "@/db/schema";
import { eq } from "drizzle-orm";
import { changeEmailSchema } from "@/lib/validation";
import { parseBody, handleApiError } from "@/lib/api-utils";
import { verifyPassword, generateToken, hashToken } from "@/lib/crypto-server";
import { requireUser, ApiError } from "@/lib/auth";
import { sendEmail, verificationEmailHtml } from "@/lib/email";
import { recordAudit } from "@/lib/audit";

export async function POST(req: NextRequest) {
  try {
    const sessionUser = await requireUser();
    const { newEmail, currentPassword } = await parseBody(req, changeEmailSchema);

    const [user] = await db.select().from(users).where(eq(users.id, sessionUser.id)).limit(1);
    if (!user) throw new ApiError("Account not found.", 404);

    const valid = await verifyPassword(currentPassword, user.passwordHash);
    if (!valid) throw new ApiError("Current password is incorrect.", 401);

    const emailLower = newEmail.toLowerCase();
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.emailLower, emailLower)).limit(1);
    if (existing.length > 0 && existing[0].id !== user.id) {
      throw new ApiError("This email address is already in use.", 409);
    }

    const token = generateToken(32);
    await db.insert(verificationTokens).values({
      userId: user.id,
      type: "email_change",
      tokenHash: hashToken(token),
      metadata: { newEmail },
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    });

    const link = `${req.nextUrl.origin}/verify-email?token=${token}`;
    await sendEmail(newEmail, "Confirm your new SecureVault Pro email", verificationEmailHtml(link));
    await recordAudit({ actorUserId: user.id, action: "user.email_change_requested" });

    return NextResponse.json({
      message: "Confirmation link sent to the new email address.",
      devVerifyLink: process.env.RESEND_API_KEY ? undefined : link,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
