import { NextResponse } from "next/server";
import { db } from "@/db";
import { loginHistory } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError } from "@/lib/api-utils";

export async function GET() {
  try {
    const user = await requireUser();
    const rows = await db
      .select()
      .from(loginHistory)
      .where(eq(loginHistory.userId, user.id))
      .orderBy(desc(loginHistory.createdAt))
      .limit(50);
    return NextResponse.json({ history: rows });
  } catch (err) {
    return handleApiError(err);
  }
}
