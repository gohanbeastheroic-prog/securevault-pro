import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  backups,
  vaultItems,
  vaultCategories,
  financeAccounts,
  financeCategories,
  financeTransactions,
  financeBudgets,
  savingsGoals,
  recurringTransactions,
  adminSettings,
} from "@/db/schema";
import { and, desc, eq, isNull } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError } from "@/lib/api-utils";
import { encryptServerSide, sha256 } from "@/lib/backup-crypto";
import { BACKUP_FORMAT_VERSION, BackupPayload } from "@/lib/backup-format";
import { recordAudit } from "@/lib/audit";
import { z } from "zod";
import { parseBody } from "@/lib/api-utils";

export async function GET() {
  try {
    const user = await requireUser();
    const rows = await db
      .select()
      .from(backups)
      .where(and(eq(backups.userId, user.id), isNull(backups.deletedAt)))
      .orderBy(desc(backups.createdAt));

    return NextResponse.json({
      backups: rows.map((b) => ({
        id: b.id,
        label: b.label,
        version: b.version,
        sizeBytes: b.sizeBytes,
        checksum: b.checksum,
        containsVault: b.containsVault,
        containsFinance: b.containsFinance,
        createdAt: b.createdAt,
      })),
    });
  } catch (err) {
    return handleApiError(err);
  }
}

const createSchema = z.object({ label: z.string().max(150).optional() });

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const { label } = await parseBody(req, createSchema);

    const [settings] = await db.select().from(adminSettings).limit(1);
    const maxBackupSize = settings?.maxBackupSizeBytes ?? 10 * 1024 * 1024;

    const [vItems, vCategories, fAccounts, fCategories, fTx, fBudgets, fGoals, fRecurring] = await Promise.all([
      db.select().from(vaultItems).where(and(eq(vaultItems.userId, user.id), isNull(vaultItems.deletedAt))),
      db.select().from(vaultCategories).where(eq(vaultCategories.userId, user.id)),
      db.select().from(financeAccounts).where(eq(financeAccounts.userId, user.id)),
      db.select().from(financeCategories).where(eq(financeCategories.userId, user.id)),
      db.select().from(financeTransactions).where(and(eq(financeTransactions.userId, user.id), isNull(financeTransactions.deletedAt))),
      db.select().from(financeBudgets).where(and(eq(financeBudgets.userId, user.id), isNull(financeBudgets.deletedAt))),
      db.select().from(savingsGoals).where(and(eq(savingsGoals.userId, user.id), isNull(savingsGoals.deletedAt))),
      db.select().from(recurringTransactions).where(and(eq(recurringTransactions.userId, user.id), isNull(recurringTransactions.deletedAt))),
    ]);

    const financeSnapshotJson = JSON.stringify({
      accounts: fAccounts,
      categories: fCategories,
      transactions: fTx,
      budgets: fBudgets,
      goals: fGoals,
      recurring: fRecurring,
    });

    const { ciphertext, iv, tag } = encryptServerSide(financeSnapshotJson);

    const payload: BackupPayload = {
      formatVersion: BACKUP_FORMAT_VERSION,
      createdAt: new Date().toISOString(),
      containsVault: true,
      containsFinance: true,
      vault: {
        categories: vCategories.map((c) => ({ id: c.id, name: c.name, icon: c.icon })),
        items: vItems.map((i) => ({
          id: i.id,
          type: i.type,
          categoryId: i.categoryId,
          ciphertext: i.ciphertext,
          iv: i.iv,
          favorite: i.favorite,
          archived: i.archived,
          sizeBytes: i.sizeBytes,
        })),
      },
      finance: { encrypted: true, ciphertext, iv, tag },
      checksum: "",
    };

    const checksum = sha256(JSON.stringify(payload));
    payload.checksum = checksum;

    const serialized = JSON.stringify(payload);
    const sizeBytes = Buffer.byteLength(serialized, "utf8");

    if (sizeBytes > maxBackupSize) {
      throw new ApiError(`Backup size (${sizeBytes} bytes) exceeds the maximum allowed (${maxBackupSize} bytes).`, 413);
    }

    const [backup] = await db
      .insert(backups)
      .values({
        userId: user.id,
        version: BACKUP_FORMAT_VERSION,
        label: label || `Backup ${new Date().toLocaleString()}`,
        payload: serialized,
        sizeBytes,
        checksum,
        containsVault: true,
        containsFinance: true,
      })
      .returning();

    await recordAudit({ actorUserId: user.id, action: "backup.created", metadata: { sizeBytes } });

    return NextResponse.json({
      backup: {
        id: backup.id,
        label: backup.label,
        version: backup.version,
        sizeBytes: backup.sizeBytes,
        checksum: backup.checksum,
        createdAt: backup.createdAt,
      },
    });
  } catch (err) {
    return handleApiError(err);
  }
}
