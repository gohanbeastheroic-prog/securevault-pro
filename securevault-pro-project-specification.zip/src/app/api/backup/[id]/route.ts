import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { backups } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError } from "@/lib/api-utils";
import { recordAudit } from "@/lib/audit";

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    const [backup] = await db.select({ id: backups.id }).from(backups).where(and(eq(backups.id, id), eq(backups.userId, user.id))).limit(1);
    if (!backup) throw new ApiError("Backup not found.", 404);

    await db.update(backups).set({ deletedAt: new Date() }).where(and(eq(backups.id, id), eq(backups.userId, user.id)));
    await recordAudit({ actorUserId: user.id, action: "backup.deleted" });
    return NextResponse.json({ message: "Backup deleted." });
  } catch (err) {
    return handleApiError(err);
  }
}
