import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { financeTransactions } from "@/db/schema";
import { and, eq, isNull, desc } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError } from "@/lib/api-utils";
import { recordAudit } from "@/lib/audit";

function csvEscape(value: unknown): string {
  const str = String(value ?? "");
  if (/[",\n]/.test(str)) return `"${str.replace(/"/g, '""')}"`;
  return str;
}

export async function GET() {
  try {
    const user = await requireUser();
    const rows = await db
      .select()
      .from(financeTransactions)
      .where(and(eq(financeTransactions.userId, user.id), isNull(financeTransactions.deletedAt)))
      .orderBy(desc(financeTransactions.date));

    const header = ["Date", "Type", "Title", "Amount", "Currency", "Payment Method", "Notes"];
    const lines = [header.join(",")];
    for (const r of rows) {
      lines.push(
        [
          new Date(r.date).toISOString().slice(0, 10),
          r.type,
          csvEscape(r.title),
          r.amount,
          r.currency,
          csvEscape(r.paymentMethod || ""),
          csvEscape(r.notes || ""),
        ].join(","),
      );
    }

    await recordAudit({ actorUserId: user.id, action: "finance.export_csv" });

    return new NextResponse(lines.join("\n"), {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="securevault-finance-export.csv"`,
      },
    });
  } catch (err) {
    return handleApiError(err);
  }
}
