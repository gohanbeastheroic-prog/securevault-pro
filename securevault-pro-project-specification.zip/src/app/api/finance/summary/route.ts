import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { financeTransactions, financeCategories, financeAccounts } from "@/db/schema";
import { and, desc, eq, gte, isNull, lt } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError } from "@/lib/api-utils";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const now = new Date();
    const month = Number(searchParams.get("month")) || now.getUTCMonth() + 1;
    const year = Number(searchParams.get("year")) || now.getUTCFullYear();

    const monthStart = new Date(Date.UTC(year, month - 1, 1));
    const monthEnd = new Date(Date.UTC(year, month, 1));
    const yearStart = new Date(Date.UTC(year, 0, 1));
    const yearEnd = new Date(Date.UTC(year + 1, 0, 1));

    const allTx = await db
      .select()
      .from(financeTransactions)
      .where(and(eq(financeTransactions.userId, user.id), isNull(financeTransactions.deletedAt), gte(financeTransactions.date, yearStart), lt(financeTransactions.date, yearEnd)));

    const categories = await db.select().from(financeCategories);
    const categoryName = new Map(categories.map((c) => [c.id, c.name]));

    const accounts = await db.select().from(financeAccounts).where(eq(financeAccounts.userId, user.id));
    const startingBalance = accounts.reduce((sum, a) => sum + Number(a.startingBalance), 0);

    let monthIncome = 0, monthExpense = 0, yearIncome = 0, yearExpense = 0;
    const expenseByCategory = new Map<string, number>();
    const incomeByCategory = new Map<string, number>();
    const monthlyTrend = new Map<string, { income: number; expense: number }>();

    // All-time balance uses all transactions regardless of year filter, so fetch separately.
    const allTimeTx = await db
      .select()
      .from(financeTransactions)
      .where(and(eq(financeTransactions.userId, user.id), isNull(financeTransactions.deletedAt)));

    let allTimeIncome = 0, allTimeExpense = 0;
    for (const t of allTimeTx) {
      const amt = Number(t.amount);
      if (t.type === "income" || t.type === "refund") allTimeIncome += amt;
      if (t.type === "expense") allTimeExpense += amt;
      if (t.type === "adjustment") allTimeIncome += amt; // can be negative
    }

    for (const t of allTx) {
      const amt = Number(t.amount);
      const d = new Date(t.date);
      const inMonth = d >= monthStart && d < monthEnd;
      const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
      const bucket = monthlyTrend.get(key) || { income: 0, expense: 0 };

      if (t.type === "income" || t.type === "refund") {
        yearIncome += amt;
        bucket.income += amt;
        if (inMonth) {
          monthIncome += amt;
          const cat = t.categoryId ? categoryName.get(t.categoryId) || "Other" : "Other";
          incomeByCategory.set(cat, (incomeByCategory.get(cat) || 0) + amt);
        }
      } else if (t.type === "expense") {
        yearExpense += amt;
        bucket.expense += amt;
        if (inMonth) {
          monthExpense += amt;
          const cat = t.categoryId ? categoryName.get(t.categoryId) || "Other" : "Other";
          expenseByCategory.set(cat, (expenseByCategory.get(cat) || 0) + amt);
        }
      } else if (t.type === "adjustment") {
        yearIncome += amt;
        bucket.income += amt;
      }
      monthlyTrend.set(key, bucket);
    }

    const recent = await db
      .select()
      .from(financeTransactions)
      .where(and(eq(financeTransactions.userId, user.id), isNull(financeTransactions.deletedAt)))
      .orderBy(desc(financeTransactions.date))
      .limit(8);

    const trend = Array.from(monthlyTrend.entries())
      .sort(([a], [b]) => (a < b ? -1 : 1))
      .map(([key, v]) => ({ month: key, income: v.income, expense: v.expense, net: v.income - v.expense }));

    return NextResponse.json({
      month,
      year,
      monthIncome,
      monthExpense,
      monthSavings: monthIncome - monthExpense,
      yearIncome,
      yearExpense,
      availableBalance: startingBalance + allTimeIncome - allTimeExpense,
      expenseBreakdown: Array.from(expenseByCategory.entries()).map(([name, value]) => ({ name, value })),
      incomeBreakdown: Array.from(incomeByCategory.entries()).map(([name, value]) => ({ name, value })),
      monthlyTrend: trend,
      recentTransactions: recent,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
