import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { financeTransactions } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { financeTransactionSchema } from "@/lib/validation";
import { recordAudit } from "@/lib/audit";
import { z } from "zod";

async function getOwned(id: string, userId: string) {
  const [row] = await db.select().from(financeTransactions).where(and(eq(financeTransactions.id, id), eq(financeTransactions.userId, userId))).limit(1);
  if (!row) throw new ApiError("Transaction not found.", 404);
  return row;
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    await getOwned(id, user.id);

    const schema = financeTransactionSchema.partial().extend({ restore: z.boolean().optional() });
    const body = await parseBody(req, schema);

    const update: Record<string, unknown> = { updatedAt: new Date() };
    if (body.type !== undefined) update.type = body.type;
    if (body.title !== undefined) update.title = body.title;
    if (body.amount !== undefined) update.amount = body.amount.toString();
    if (body.currency !== undefined) update.currency = body.currency;
    if (body.categoryId !== undefined) update.categoryId = body.categoryId;
    if (body.accountId !== undefined) update.accountId = body.accountId;
    if (body.transferToAccountId !== undefined) update.transferToAccountId = body.transferToAccountId;
    if (body.paymentMethod !== undefined) update.paymentMethod = body.paymentMethod;
    if (body.date !== undefined) update.date = new Date(body.date);
    if (body.notes !== undefined) update.notes = body.notes;
    if (body.hasReceipt !== undefined) update.hasReceipt = body.hasReceipt;
    if (body.receiptNote !== undefined) update.receiptNote = body.receiptNote;
    if (body.restore) update.deletedAt = null;

    const [updated] = await db
      .update(financeTransactions)
      .set(update)
      .where(and(eq(financeTransactions.id, id), eq(financeTransactions.userId, user.id)))
      .returning();

    return NextResponse.json({ transaction: updated });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    const tx = await getOwned(id, user.id);
    const { searchParams } = new URL(req.url);
    const permanent = searchParams.get("permanent") === "true";

    if (permanent) {
      if (!tx.deletedAt) throw new ApiError("Move the transaction to trash before permanently deleting it.", 400);
      await db.delete(financeTransactions).where(and(eq(financeTransactions.id, id), eq(financeTransactions.userId, user.id)));
      return NextResponse.json({ message: "Transaction permanently deleted." });
    }

    await db.update(financeTransactions).set({ deletedAt: new Date() }).where(and(eq(financeTransactions.id, id), eq(financeTransactions.userId, user.id)));
    await recordAudit({ actorUserId: user.id, action: "finance.transaction_deleted" });
    return NextResponse.json({ message: "Transaction moved to trash." });
  } catch (err) {
    return handleApiError(err);
  }
}
