import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { financeTransactions } from "@/db/schema";
import { and, desc, eq, gte, isNull, lt, isNotNull } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { financeTransactionSchema } from "@/lib/validation";
import { recordAudit } from "@/lib/audit";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const month = searchParams.get("month");
    const year = searchParams.get("year");
    const type = searchParams.get("type");
    const trashed = searchParams.get("trashed") === "true";
    const page = Math.max(1, Number(searchParams.get("page") || 1));
    const pageSize = Math.min(100, Math.max(1, Number(searchParams.get("pageSize") || 50)));

    const conditions = [eq(financeTransactions.userId, user.id)];
    conditions.push(trashed ? isNotNull(financeTransactions.deletedAt) : isNull(financeTransactions.deletedAt));
    if (type) conditions.push(eq(financeTransactions.type, type));

    if (month && year) {
      const m = Number(month);
      const y = Number(year);
      const start = new Date(Date.UTC(y, m - 1, 1));
      const end = new Date(Date.UTC(y, m, 1));
      conditions.push(gte(financeTransactions.date, start));
      conditions.push(lt(financeTransactions.date, end));
    } else if (year) {
      const y = Number(year);
      conditions.push(gte(financeTransactions.date, new Date(Date.UTC(y, 0, 1))));
      conditions.push(lt(financeTransactions.date, new Date(Date.UTC(y + 1, 0, 1))));
    }

    const rows = await db
      .select()
      .from(financeTransactions)
      .where(and(...conditions))
      .orderBy(desc(financeTransactions.date))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    return NextResponse.json({ transactions: rows, page, pageSize });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, financeTransactionSchema);

    if (body.type === "transfer" && !body.transferToAccountId) {
      throw new ApiError("A destination account is required for transfers.", 422);
    }

    const date = new Date(body.date);
    if (Number.isNaN(date.getTime())) throw new ApiError("Invalid date.", 422);

    const [tx] = await db
      .insert(financeTransactions)
      .values({
        userId: user.id,
        type: body.type,
        title: body.title,
        amount: body.amount.toString(),
        currency: body.currency,
        categoryId: body.categoryId || null,
        accountId: body.accountId || null,
        transferToAccountId: body.transferToAccountId || null,
        paymentMethod: body.paymentMethod,
        date,
        notes: body.notes,
        hasReceipt: body.hasReceipt ?? false,
        receiptNote: body.receiptNote,
      })
      .returning();

    await recordAudit({ actorUserId: user.id, action: "finance.transaction_created", metadata: { type: body.type } });

    return NextResponse.json({ transaction: tx });
  } catch (err) {
    return handleApiError(err);
  }
}
