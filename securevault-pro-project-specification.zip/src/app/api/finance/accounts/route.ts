import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { financeAccounts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { financeAccountSchema } from "@/lib/validation";

export async function GET() {
  try {
    const user = await requireUser();
    const rows = await db.select().from(financeAccounts).where(eq(financeAccounts.userId, user.id));
    return NextResponse.json({ accounts: rows });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, financeAccountSchema);
    const [account] = await db
      .insert(financeAccounts)
      .values({
        userId: user.id,
        name: body.name,
        type: body.type,
        currency: body.currency,
        startingBalance: body.startingBalance.toString(),
      })
      .returning();
    return NextResponse.json({ account });
  } catch (err) {
    return handleApiError(err);
  }
}
