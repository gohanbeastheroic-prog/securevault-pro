import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { financeAccounts } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError } from "@/lib/api-utils";

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    const [existing] = await db.select({ id: financeAccounts.id }).from(financeAccounts).where(and(eq(financeAccounts.id, id), eq(financeAccounts.userId, user.id))).limit(1);
    if (!existing) throw new ApiError("Account not found.", 404);
    await db.update(financeAccounts).set({ archived: true }).where(and(eq(financeAccounts.id, id), eq(financeAccounts.userId, user.id)));
    return NextResponse.json({ message: "Account archived." });
  } catch (err) {
    return handleApiError(err);
  }
}
