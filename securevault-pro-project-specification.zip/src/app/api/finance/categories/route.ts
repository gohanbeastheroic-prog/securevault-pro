import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { financeCategories } from "@/db/schema";
import { eq, isNull, or } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { financeCategorySchema } from "@/lib/validation";

export async function GET() {
  try {
    const user = await requireUser();
    const rows = await db
      .select()
      .from(financeCategories)
      .where(or(isNull(financeCategories.userId), eq(financeCategories.userId, user.id)));
    return NextResponse.json({ categories: rows });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, financeCategorySchema);
    const [category] = await db
      .insert(financeCategories)
      .values({ userId: user.id, name: body.name, type: body.type, icon: body.icon })
      .returning();
    return NextResponse.json({ category });
  } catch (err) {
    return handleApiError(err);
  }
}
