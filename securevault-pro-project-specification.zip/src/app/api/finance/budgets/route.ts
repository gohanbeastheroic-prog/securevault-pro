import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { financeBudgets, financeTransactions } from "@/db/schema";
import { and, eq, isNull, gte, lt } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { financeBudgetSchema } from "@/lib/validation";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const month = Number(searchParams.get("month")) || new Date().getMonth() + 1;
    const year = Number(searchParams.get("year")) || new Date().getFullYear();

    const budgets = await db
      .select()
      .from(financeBudgets)
      .where(and(eq(financeBudgets.userId, user.id), eq(financeBudgets.month, month), eq(financeBudgets.year, year), isNull(financeBudgets.deletedAt)));

    const start = new Date(Date.UTC(year, month - 1, 1));
    const end = new Date(Date.UTC(year, month, 1));
    const expenses = await db
      .select()
      .from(financeTransactions)
      .where(
        and(
          eq(financeTransactions.userId, user.id),
          eq(financeTransactions.type, "expense"),
          isNull(financeTransactions.deletedAt),
          gte(financeTransactions.date, start),
          lt(financeTransactions.date, end),
        ),
      );

    const spentByCategory = new Map<string, number>();
    let totalSpent = 0;
    for (const e of expenses) {
      const amt = Number(e.amount);
      totalSpent += amt;
      if (e.categoryId) spentByCategory.set(e.categoryId, (spentByCategory.get(e.categoryId) || 0) + amt);
    }

    const result = budgets.map((b) => ({
      ...b,
      spent: b.categoryId ? spentByCategory.get(b.categoryId) || 0 : totalSpent,
    }));

    return NextResponse.json({ budgets: result });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, financeBudgetSchema);
    const [budget] = await db
      .insert(financeBudgets)
      .values({
        userId: user.id,
        name: body.name,
        categoryId: body.categoryId || null,
        amount: body.amount.toString(),
        month: body.month,
        year: body.year,
      })
      .returning();
    return NextResponse.json({ budget });
  } catch (err) {
    return handleApiError(err);
  }
}
