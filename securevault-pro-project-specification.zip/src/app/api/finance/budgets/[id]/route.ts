import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { financeBudgets } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError } from "@/lib/api-utils";

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    await db.update(financeBudgets).set({ deletedAt: new Date() }).where(and(eq(financeBudgets.id, id), eq(financeBudgets.userId, user.id)));
    return NextResponse.json({ message: "Budget removed." });
  } catch (err) {
    return handleApiError(err);
  }
}
