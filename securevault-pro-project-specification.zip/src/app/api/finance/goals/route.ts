import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { savingsGoals } from "@/db/schema";
import { and, eq, isNull } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { savingsGoalSchema } from "@/lib/validation";

export async function GET() {
  try {
    const user = await requireUser();
    const rows = await db.select().from(savingsGoals).where(and(eq(savingsGoals.userId, user.id), isNull(savingsGoals.deletedAt)));
    return NextResponse.json({ goals: rows });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, savingsGoalSchema);
    const [goal] = await db
      .insert(savingsGoals)
      .values({
        userId: user.id,
        name: body.name,
        targetAmount: body.targetAmount.toString(),
        currentAmount: body.currentAmount.toString(),
        targetDate: body.targetDate ? new Date(body.targetDate) : null,
        notes: body.notes,
      })
      .returning();
    return NextResponse.json({ goal });
  } catch (err) {
    return handleApiError(err);
  }
}
