import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { savingsGoals } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser, ApiError } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";

const schema = z.object({
  name: z.string().min(1).max(150).optional(),
  targetAmount: z.number().positive().optional(),
  currentAmount: z.number().min(0).optional(),
  targetDate: z.string().nullable().optional(),
  notes: z.string().max(2000).optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    const [existing] = await db.select().from(savingsGoals).where(and(eq(savingsGoals.id, id), eq(savingsGoals.userId, user.id))).limit(1);
    if (!existing) throw new ApiError("Savings goal not found.", 404);

    const body = await parseBody(req, schema);
    const update: Record<string, unknown> = { updatedAt: new Date() };
    if (body.name !== undefined) update.name = body.name;
    if (body.targetAmount !== undefined) update.targetAmount = body.targetAmount.toString();
    if (body.currentAmount !== undefined) {
      update.currentAmount = body.currentAmount.toString();
      if (body.currentAmount >= Number(body.targetAmount ?? existing.targetAmount)) update.completedAt = new Date();
    }
    if (body.targetDate !== undefined) update.targetDate = body.targetDate ? new Date(body.targetDate) : null;
    if (body.notes !== undefined) update.notes = body.notes;

    const [goal] = await db.update(savingsGoals).set(update).where(and(eq(savingsGoals.id, id), eq(savingsGoals.userId, user.id))).returning();
    return NextResponse.json({ goal });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    await db.update(savingsGoals).set({ deletedAt: new Date() }).where(and(eq(savingsGoals.id, id), eq(savingsGoals.userId, user.id)));
    return NextResponse.json({ message: "Savings goal removed." });
  } catch (err) {
    return handleApiError(err);
  }
}
