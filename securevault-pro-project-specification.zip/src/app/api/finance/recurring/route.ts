import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { recurringTransactions, financeTransactions } from "@/db/schema";
import { and, eq, isNull, lte } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";
import { recurringTransactionSchema } from "@/lib/validation";

function nextRunDate(from: Date, frequency: string): Date {
  const d = new Date(from);
  switch (frequency) {
    case "daily": d.setUTCDate(d.getUTCDate() + 1); break;
    case "weekly": d.setUTCDate(d.getUTCDate() + 7); break;
    case "monthly": d.setUTCMonth(d.getUTCMonth() + 1); break;
    case "yearly": d.setUTCFullYear(d.getUTCFullYear() + 1); break;
  }
  return d;
}

/** Process any due recurring rules for this user, generating transactions without duplicates. */
async function processDue(userId: string) {
  const now = new Date();
  const due = await db
    .select()
    .from(recurringTransactions)
    .where(and(eq(recurringTransactions.userId, userId), eq(recurringTransactions.active, true), isNull(recurringTransactions.deletedAt), lte(recurringTransactions.nextRunDate, now)));

  for (const rule of due) {
    let runDate = new Date(rule.nextRunDate);
    let guard = 0;
    while (runDate <= now && guard < 500) {
      await db.insert(financeTransactions).values({
        userId,
        type: rule.type,
        title: `${rule.title} (recurring)`,
        amount: rule.amount,
        currency: rule.currency,
        categoryId: rule.categoryId,
        accountId: rule.accountId,
        paymentMethod: rule.paymentMethod,
        date: runDate,
        notes: rule.notes,
        recurringId: rule.id,
      });
      runDate = nextRunDate(runDate, rule.frequency);
      guard++;
    }
    await db.update(recurringTransactions).set({ nextRunDate: runDate, lastProcessedDate: now }).where(eq(recurringTransactions.id, rule.id));
  }
}

export async function GET() {
  try {
    const user = await requireUser();
    await processDue(user.id);
    const rows = await db.select().from(recurringTransactions).where(and(eq(recurringTransactions.userId, user.id), isNull(recurringTransactions.deletedAt)));
    return NextResponse.json({ recurring: rows });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, recurringTransactionSchema);
    const startDate = new Date(body.startDate);

    const [rule] = await db
      .insert(recurringTransactions)
      .values({
        userId: user.id,
        type: body.type,
        title: body.title,
        amount: body.amount.toString(),
        currency: body.currency,
        categoryId: body.categoryId || null,
        accountId: body.accountId || null,
        paymentMethod: body.paymentMethod,
        frequency: body.frequency,
        startDate,
        nextRunDate: startDate,
        notes: body.notes,
        active: body.active ?? true,
      })
      .returning();

    return NextResponse.json({ recurring: rule });
  } catch (err) {
    return handleApiError(err);
  }
}
