import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { recurringTransactions } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { handleApiError, parseBody } from "@/lib/api-utils";

const schema = z.object({ active: z.boolean().optional() });

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    const body = await parseBody(req, schema);
    const [rule] = await db
      .update(recurringTransactions)
      .set({ active: body.active })
      .where(and(eq(recurringTransactions.id, id), eq(recurringTransactions.userId, user.id)))
      .returning();
    return NextResponse.json({ recurring: rule });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    await db.update(recurringTransactions).set({ deletedAt: new Date(), active: false }).where(and(eq(recurringTransactions.id, id), eq(recurringTransactions.userId, user.id)));
    return NextResponse.json({ message: "Recurring rule removed." });
  } catch (err) {
    return handleApiError(err);
  }
}
